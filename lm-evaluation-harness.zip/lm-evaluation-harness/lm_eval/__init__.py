import logging
import os

from .evaluator import evaluate, simple_evaluate


__version__ = "0.4.8"
