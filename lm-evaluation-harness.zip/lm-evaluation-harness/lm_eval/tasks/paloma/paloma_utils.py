def doc_to_target(doc):
    return str(doc["text"])
