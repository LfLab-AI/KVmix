lm_eval --model hf \
    --model_args pretrained=/path/your_model \
    --tasks wikitext \
    --device cuda:0 \
    --batch_size 4
